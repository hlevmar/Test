<?php
/**
 *
 * @author        RadiusTheme
 * @package    classified-listing/templates
 * @version     1.0.0
 */

use Rtcl\Helpers\Functions;

?>

<?php Functions::print_notices(); ?>
